package com.zws.android.bean.mingli;

/**
 * Created by weihao on 2018/1/10.
 */

/*
* 用来区分命理页面，head，和热门测算的数据类型
* */

public class T {
}
