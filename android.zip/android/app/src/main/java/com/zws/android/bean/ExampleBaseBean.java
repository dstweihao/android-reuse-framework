package com.zws.android.bean;

public class ExampleBaseBean {

    private int viewType;


    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }


}

