package com.zws.android.constant.home;

/**
 * Created by weihao on 2018/1/6.
 */

public class HomeType {

    public static final int TOMORROW = 1;
    public static final int WEEK = 2;
    public static final int MONTH = 3;
    public static final int YEAR = 4;
}
