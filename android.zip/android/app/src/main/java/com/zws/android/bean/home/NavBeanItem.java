package com.zws.android.bean.home;

import java.util.List;

public class NavBeanItem {

    private int image;
    private String num;
    private String text;

    public NavBeanItem(int image, String num, String text) {
        this.image = image;
        this.num = num;
        this.text = text;
    }
}
