package com.zws.android.constant.xuetang;

/**
 * Created by weihao on 2018/1/15.
 */

public class MVType {
    public final static int JINGXUAN = 0; //精选推荐
    public final static int REMEN = 1;  //热门好课
    public final static int TEJIA = 2;  //限时特价
    public final static int HAOPING = 3; //好评爆款
    public final static int ZHUANLAN = 4; //专栏推荐
    public final static int KECHENG = 5; //课程推荐


}
