package com.zws.android.bean.xuetang;

import java.util.List;

/**
 * Created by weihao on 2018/3/1.
 */

public class NewTweet {

    /**
     * code : 1
     * message : SUCCESS
     * result : {"items":[{"appClient":1,"author":{"id":3713126,"identity":{"officialMember":false,"softwareAuthor":false},"name":"江河君","portrait":"http://static.oschina.net/uploads/user/1856/3713126_50.jpg?t=1508725466000","relation":0},"commentCount":0,"content":"何以解忧?唯有吃肉.","href":"https://my.oschina.net/u/3713126/tweet/16632053","id":16632053,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:56:24","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1248037,"identity":{"officialMember":false,"softwareAuthor":false},"name":"admin001","portrait":"http://static.oschina.net/uploads/user/624/1248037_50.jpeg?t=1511762785000","relation":0},"commentCount":0,"content":"乱弹打不开，看到这样的标题很想点进去看看\u201cOSChina 正月十四乱弹 \u2014\u2014 公司的财务是个大美女\u201d","href":"https://my.oschina.net/u/1248037/tweet/16632049","id":16632049,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:55:37","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1405616,"identity":{"officialMember":false,"softwareAuthor":false},"name":"h21314","portrait":"http://static.oschina.net/uploads/user/702/1405616_50.jpg?t=1411720388000","relation":0},"commentCount":0,"content":"时刻保持危机意识","href":"https://my.oschina.net/u/1405616/tweet/16632048","id":16632048,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:55:35","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":3,"author":{"id":2523704,"identity":{"officialMember":false,"softwareAuthor":false},"name":"奋斗的斗斗","portrait":"http://static.oschina.net/uploads/user/1261/2523704_50.jpeg?t=1495440485000","relation":0},"commentCount":0,"content":"都在厕所里过年呢，20分钟了没一个人出来","href":"https://my.oschina.net/u/2523704/tweet/16632046","id":16632046,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:55:18","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":3784993,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Xu_xxx","portrait":"http://www.oschina.net/img/portrait.gif","relation":0},"commentCount":0,"content":"要搞挂他做啥。 ","href":"https://my.oschina.net/u/3784993/tweet/16632026","id":16632026,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:54:01","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":115076,"identity":{"officialMember":false,"softwareAuthor":false},"name":"whaon","portrait":"http://static.oschina.net/uploads/user/57/115076_50.jpg","relation":0},"commentCount":0,"content":"挂了？","href":"https://my.oschina.net/dxqr/tweet/16632016","id":16632016,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:53:08","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2991530,"identity":{"officialMember":false,"softwareAuthor":false},"name":"开源中国首席大色情","portrait":"http://static.oschina.net/uploads/user/1495/2991530_50.jpeg?t=1517456965000","relation":0},"commentCount":0,"content":"  是","href":"https://my.oschina.net/mecso/tweet/16632009","id":16632009,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:52:34","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":856962,"identity":{"officialMember":false,"softwareAuthor":false},"name":"waising","portrait":"http://static.oschina.net/uploads/user/428/856962_50.jpeg?t=1486359365000","relation":0},"commentCount":0,"content":"还好动弹没有挂。。","href":"https://my.oschina.net/waising/tweet/16632006","id":16632006,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:52:04","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":25213,"identity":{"officialMember":false,"softwareAuthor":true},"name":"小熊宝宝","portrait":"http://static.oschina.net/uploads/user/12/25213_50.jpg?t=1464758497000","relation":0},"commentCount":0,"content":"服务器要挂了，哈哈哈","href":"https://my.oschina.net/hemiya/tweet/16632005","id":16632005,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:51:33","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1456141,"identity":{"officialMember":false,"softwareAuthor":true},"name":"金拱门","portrait":"http://static.oschina.net/uploads/user/728/1456141_50.jpg?t=1513508704000","relation":0},"commentCount":0,"content":"该项目已被设置为私有项目，需要输入提取码才可查看 ？？？？？？？？？？","href":"https://my.oschina.net/Felldeadbird/tweet/16632001","id":16632001,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:51:08","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":12,"identity":{"officialMember":true,"softwareAuthor":true},"name":"红薯","portrait":"http://static.oschina.net/uploads/user/0/12_50.jpg?t=1421200584000","relation":0},"commentCount":0,"content":"空间出问题了，服务一启动就立即队列满。。。。","href":"https://my.oschina.net/javayou/tweet/16631991","id":16631991,"likeCount":2,"liked":false,"pubDate":"2018-03-01 14:50:16","statistics":{"comment":0,"favCount":0,"like":2,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2853464,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Suncici","portrait":"http://static.oschina.net/uploads/user/1426/2853464_50.jpg?t=1519815947000","relation":0},"commentCount":0,"content":"人都有贪图安逸的念头，那就好像来自地心让你不断下坠堕落的力量。","href":"https://my.oschina.net/suncici1101/tweet/16631987","id":16631987,"likeCount":1,"liked":false,"pubDate":"2018-03-01 14:49:23","statistics":{"comment":0,"favCount":0,"like":1,"transmit":0,"view":0}},{"appClient":1,"author":{"id":347223,"identity":{"officialMember":false,"softwareAuthor":false},"name":"clouddyy","portrait":"http://static.oschina.net/uploads/user/173/347223_50.jpeg?t=1477362397000","relation":0},"commentCount":0,"content":"OSC换PGSQL？","href":"https://my.oschina.net/clouddyy/tweet/16631984","id":16631984,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:49:13","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":3214331,"identity":{"officialMember":false,"softwareAuthor":false},"name":"roc_young","portrait":"http://static.oschina.net/uploads/user/1607/3214331_50.jpg?t=1484197026000","relation":0},"commentCount":0,"content":"快修修！","href":"https://my.oschina.net/u/3214331/tweet/16631973","id":16631973,"likeCount":1,"liked":false,"pubDate":"2018-03-01 14:47:37","statistics":{"comment":0,"favCount":0,"like":1,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2842977,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Lunma","portrait":"http://static.oschina.net/uploads/user/1421/2842977_50.jpeg?t=1490272835000","relation":0},"commentCount":0,"content":"又被DDOS了？","href":"https://my.oschina.net/lunma/tweet/16631966","id":16631966,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:46:40","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":96003,"identity":{"officialMember":false,"softwareAuthor":false},"name":"宏哥","portrait":"http://static.oschina.net/uploads/user/48/96003_50.jpg?t=1368158428000","relation":0},"commentCount":0,"content":"OSC的死锁太频繁了， 都是mysql 的功劳 ","href":"https://my.oschina.net/anthonychen/tweet/16631959","id":16631959,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:46:10","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1265258,"identity":{"officialMember":false,"softwareAuthor":false},"name":"贪吃飒","portrait":"http://static.oschina.net/uploads/user/632/1265258_50.jpeg?t=1511253491000","relation":0},"commentCount":0,"content":"我有个大胆的建议，可以让osc流量少90%，就是我们自己开发个动弹功能，不要来osc玩动弹了，","href":"https://my.oschina.net/asan123/tweet/16631955","id":16631955,"likeCount":1,"liked":false,"pubDate":"2018-03-01 14:45:55","statistics":{"comment":0,"favCount":0,"like":1,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1862214,"identity":{"officialMember":false,"softwareAuthor":false},"name":"大二师兄","portrait":"http://www.oschina.net/img/portrait.gif","relation":0},"commentCount":0,"content":"动弹明细打不开","href":"https://my.oschina.net/u/1862214/tweet/16631954","id":16631954,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:45:46","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1014946,"identity":{"officialMember":false,"softwareAuthor":false},"name":"开源中国-鲁迅","portrait":"http://static.oschina.net/uploads/user/507/1014946_50.jpg?t=1511336589000","relation":0},"commentCount":0,"content":"焖的烂不烂？  烂不烂问厨房，25块半   不如我请吧.几十岁人了,四十多块钱东西推来推去的,去刷卡啊,笨蛋!  啊,别动啊!要不就给钱!要不就拿走!要不然就我请!","href":"https://my.oschina.net/u/1014946/tweet/16631952","id":16631952,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:45:34","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2295159,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Crab2Died","portrait":"http://static.oschina.net/uploads/user/1147/2295159_50.jpeg?t=1496037280000","relation":0},"commentCount":0,"content":"听说Apache要把项目全部迁移到码云？ 惊不惊喜，意不意外","href":"https://my.oschina.net/crab2died/tweet/16631945","id":16631945,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:44:37","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}}],"nextPageToken":"69872E8D4CFDCEF84AD6659CDD5740BA","prevPageToken":"DE86BF6D3CAC483F9A47EC1668BC550B","requestCount":20,"responseCount":20,"totalResults":1000}
     * time : 2018-03-01 14:56:30
     */

    private int code;
    private String message;
    private ResultBean result;
    private String time;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public static class ResultBean {
        /**
         * items : [{"appClient":1,"author":{"id":3713126,"identity":{"officialMember":false,"softwareAuthor":false},"name":"江河君","portrait":"http://static.oschina.net/uploads/user/1856/3713126_50.jpg?t=1508725466000","relation":0},"commentCount":0,"content":"何以解忧?唯有吃肉.","href":"https://my.oschina.net/u/3713126/tweet/16632053","id":16632053,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:56:24","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1248037,"identity":{"officialMember":false,"softwareAuthor":false},"name":"admin001","portrait":"http://static.oschina.net/uploads/user/624/1248037_50.jpeg?t=1511762785000","relation":0},"commentCount":0,"content":"乱弹打不开，看到这样的标题很想点进去看看\u201cOSChina 正月十四乱弹 \u2014\u2014 公司的财务是个大美女\u201d","href":"https://my.oschina.net/u/1248037/tweet/16632049","id":16632049,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:55:37","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1405616,"identity":{"officialMember":false,"softwareAuthor":false},"name":"h21314","portrait":"http://static.oschina.net/uploads/user/702/1405616_50.jpg?t=1411720388000","relation":0},"commentCount":0,"content":"时刻保持危机意识","href":"https://my.oschina.net/u/1405616/tweet/16632048","id":16632048,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:55:35","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":3,"author":{"id":2523704,"identity":{"officialMember":false,"softwareAuthor":false},"name":"奋斗的斗斗","portrait":"http://static.oschina.net/uploads/user/1261/2523704_50.jpeg?t=1495440485000","relation":0},"commentCount":0,"content":"都在厕所里过年呢，20分钟了没一个人出来","href":"https://my.oschina.net/u/2523704/tweet/16632046","id":16632046,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:55:18","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":3784993,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Xu_xxx","portrait":"http://www.oschina.net/img/portrait.gif","relation":0},"commentCount":0,"content":"要搞挂他做啥。 ","href":"https://my.oschina.net/u/3784993/tweet/16632026","id":16632026,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:54:01","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":115076,"identity":{"officialMember":false,"softwareAuthor":false},"name":"whaon","portrait":"http://static.oschina.net/uploads/user/57/115076_50.jpg","relation":0},"commentCount":0,"content":"挂了？","href":"https://my.oschina.net/dxqr/tweet/16632016","id":16632016,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:53:08","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2991530,"identity":{"officialMember":false,"softwareAuthor":false},"name":"开源中国首席大色情","portrait":"http://static.oschina.net/uploads/user/1495/2991530_50.jpeg?t=1517456965000","relation":0},"commentCount":0,"content":"  是","href":"https://my.oschina.net/mecso/tweet/16632009","id":16632009,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:52:34","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":856962,"identity":{"officialMember":false,"softwareAuthor":false},"name":"waising","portrait":"http://static.oschina.net/uploads/user/428/856962_50.jpeg?t=1486359365000","relation":0},"commentCount":0,"content":"还好动弹没有挂。。","href":"https://my.oschina.net/waising/tweet/16632006","id":16632006,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:52:04","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":25213,"identity":{"officialMember":false,"softwareAuthor":true},"name":"小熊宝宝","portrait":"http://static.oschina.net/uploads/user/12/25213_50.jpg?t=1464758497000","relation":0},"commentCount":0,"content":"服务器要挂了，哈哈哈","href":"https://my.oschina.net/hemiya/tweet/16632005","id":16632005,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:51:33","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1456141,"identity":{"officialMember":false,"softwareAuthor":true},"name":"金拱门","portrait":"http://static.oschina.net/uploads/user/728/1456141_50.jpg?t=1513508704000","relation":0},"commentCount":0,"content":"该项目已被设置为私有项目，需要输入提取码才可查看 ？？？？？？？？？？","href":"https://my.oschina.net/Felldeadbird/tweet/16632001","id":16632001,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:51:08","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":12,"identity":{"officialMember":true,"softwareAuthor":true},"name":"红薯","portrait":"http://static.oschina.net/uploads/user/0/12_50.jpg?t=1421200584000","relation":0},"commentCount":0,"content":"空间出问题了，服务一启动就立即队列满。。。。","href":"https://my.oschina.net/javayou/tweet/16631991","id":16631991,"likeCount":2,"liked":false,"pubDate":"2018-03-01 14:50:16","statistics":{"comment":0,"favCount":0,"like":2,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2853464,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Suncici","portrait":"http://static.oschina.net/uploads/user/1426/2853464_50.jpg?t=1519815947000","relation":0},"commentCount":0,"content":"人都有贪图安逸的念头，那就好像来自地心让你不断下坠堕落的力量。","href":"https://my.oschina.net/suncici1101/tweet/16631987","id":16631987,"likeCount":1,"liked":false,"pubDate":"2018-03-01 14:49:23","statistics":{"comment":0,"favCount":0,"like":1,"transmit":0,"view":0}},{"appClient":1,"author":{"id":347223,"identity":{"officialMember":false,"softwareAuthor":false},"name":"clouddyy","portrait":"http://static.oschina.net/uploads/user/173/347223_50.jpeg?t=1477362397000","relation":0},"commentCount":0,"content":"OSC换PGSQL？","href":"https://my.oschina.net/clouddyy/tweet/16631984","id":16631984,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:49:13","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":3214331,"identity":{"officialMember":false,"softwareAuthor":false},"name":"roc_young","portrait":"http://static.oschina.net/uploads/user/1607/3214331_50.jpg?t=1484197026000","relation":0},"commentCount":0,"content":"快修修！","href":"https://my.oschina.net/u/3214331/tweet/16631973","id":16631973,"likeCount":1,"liked":false,"pubDate":"2018-03-01 14:47:37","statistics":{"comment":0,"favCount":0,"like":1,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2842977,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Lunma","portrait":"http://static.oschina.net/uploads/user/1421/2842977_50.jpeg?t=1490272835000","relation":0},"commentCount":0,"content":"又被DDOS了？","href":"https://my.oschina.net/lunma/tweet/16631966","id":16631966,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:46:40","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":96003,"identity":{"officialMember":false,"softwareAuthor":false},"name":"宏哥","portrait":"http://static.oschina.net/uploads/user/48/96003_50.jpg?t=1368158428000","relation":0},"commentCount":0,"content":"OSC的死锁太频繁了， 都是mysql 的功劳 ","href":"https://my.oschina.net/anthonychen/tweet/16631959","id":16631959,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:46:10","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1265258,"identity":{"officialMember":false,"softwareAuthor":false},"name":"贪吃飒","portrait":"http://static.oschina.net/uploads/user/632/1265258_50.jpeg?t=1511253491000","relation":0},"commentCount":0,"content":"我有个大胆的建议，可以让osc流量少90%，就是我们自己开发个动弹功能，不要来osc玩动弹了，","href":"https://my.oschina.net/asan123/tweet/16631955","id":16631955,"likeCount":1,"liked":false,"pubDate":"2018-03-01 14:45:55","statistics":{"comment":0,"favCount":0,"like":1,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1862214,"identity":{"officialMember":false,"softwareAuthor":false},"name":"大二师兄","portrait":"http://www.oschina.net/img/portrait.gif","relation":0},"commentCount":0,"content":"动弹明细打不开","href":"https://my.oschina.net/u/1862214/tweet/16631954","id":16631954,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:45:46","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":1014946,"identity":{"officialMember":false,"softwareAuthor":false},"name":"开源中国-鲁迅","portrait":"http://static.oschina.net/uploads/user/507/1014946_50.jpg?t=1511336589000","relation":0},"commentCount":0,"content":"焖的烂不烂？  烂不烂问厨房，25块半   不如我请吧.几十岁人了,四十多块钱东西推来推去的,去刷卡啊,笨蛋!  啊,别动啊!要不就给钱!要不就拿走!要不然就我请!","href":"https://my.oschina.net/u/1014946/tweet/16631952","id":16631952,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:45:34","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}},{"appClient":1,"author":{"id":2295159,"identity":{"officialMember":false,"softwareAuthor":false},"name":"Crab2Died","portrait":"http://static.oschina.net/uploads/user/1147/2295159_50.jpeg?t=1496037280000","relation":0},"commentCount":0,"content":"听说Apache要把项目全部迁移到码云？ 惊不惊喜，意不意外","href":"https://my.oschina.net/crab2died/tweet/16631945","id":16631945,"likeCount":0,"liked":false,"pubDate":"2018-03-01 14:44:37","statistics":{"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}}]
         * nextPageToken : 69872E8D4CFDCEF84AD6659CDD5740BA
         * prevPageToken : DE86BF6D3CAC483F9A47EC1668BC550B
         * requestCount : 20
         * responseCount : 20
         * totalResults : 1000
         */

        private String nextPageToken;
        private String prevPageToken;
        private int requestCount;
        private int responseCount;
        private int totalResults;
        private List<ItemsBean> items;

        public String getNextPageToken() {
            return nextPageToken;
        }

        public void setNextPageToken(String nextPageToken) {
            this.nextPageToken = nextPageToken;
        }

        public String getPrevPageToken() {
            return prevPageToken;
        }

        public void setPrevPageToken(String prevPageToken) {
            this.prevPageToken = prevPageToken;
        }

        public int getRequestCount() {
            return requestCount;
        }

        public void setRequestCount(int requestCount) {
            this.requestCount = requestCount;
        }

        public int getResponseCount() {
            return responseCount;
        }

        public void setResponseCount(int responseCount) {
            this.responseCount = responseCount;
        }

        public int getTotalResults() {
            return totalResults;
        }

        public void setTotalResults(int totalResults) {
            this.totalResults = totalResults;
        }

        public List<ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<ItemsBean> items) {
            this.items = items;
        }

        public static class ItemsBean {
            /**
             * appClient : 1
             * author : {"id":3713126,"identity":{"officialMember":false,"softwareAuthor":false},"name":"江河君","portrait":"http://static.oschina.net/uploads/user/1856/3713126_50.jpg?t=1508725466000","relation":0}
             * commentCount : 0
             * content : 何以解忧?唯有吃肉.
             * href : https://my.oschina.net/u/3713126/tweet/16632053
             * id : 16632053
             * likeCount : 0
             * liked : false
             * pubDate : 2018-03-01 14:56:24
             * statistics : {"comment":0,"favCount":0,"like":0,"transmit":0,"view":0}
             */

            private int appClient;
            private AuthorBean author;
            private int commentCount;
            private String content;
            private String href;
            private int id;
            private int likeCount;
            private boolean liked;
            private String pubDate;
            private StatisticsBean statistics;

            public int getAppClient() {
                return appClient;
            }

            public void setAppClient(int appClient) {
                this.appClient = appClient;
            }

            public AuthorBean getAuthor() {
                return author;
            }

            public void setAuthor(AuthorBean author) {
                this.author = author;
            }

            public int getCommentCount() {
                return commentCount;
            }

            public void setCommentCount(int commentCount) {
                this.commentCount = commentCount;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getHref() {
                return href;
            }

            public void setHref(String href) {
                this.href = href;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getLikeCount() {
                return likeCount;
            }

            public void setLikeCount(int likeCount) {
                this.likeCount = likeCount;
            }

            public boolean isLiked() {
                return liked;
            }

            public void setLiked(boolean liked) {
                this.liked = liked;
            }

            public String getPubDate() {
                return pubDate;
            }

            public void setPubDate(String pubDate) {
                this.pubDate = pubDate;
            }

            public StatisticsBean getStatistics() {
                return statistics;
            }

            public void setStatistics(StatisticsBean statistics) {
                this.statistics = statistics;
            }

            public static class AuthorBean {
                /**
                 * id : 3713126
                 * identity : {"officialMember":false,"softwareAuthor":false}
                 * name : 江河君
                 * portrait : http://static.oschina.net/uploads/user/1856/3713126_50.jpg?t=1508725466000
                 * relation : 0
                 */

                private int id;
                private IdentityBean identity;
                private String name;
                private String portrait;
                private int relation;

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public IdentityBean getIdentity() {
                    return identity;
                }

                public void setIdentity(IdentityBean identity) {
                    this.identity = identity;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getPortrait() {
                    return portrait;
                }

                public void setPortrait(String portrait) {
                    this.portrait = portrait;
                }

                public int getRelation() {
                    return relation;
                }

                public void setRelation(int relation) {
                    this.relation = relation;
                }

                public static class IdentityBean {
                    /**
                     * officialMember : false
                     * softwareAuthor : false
                     */

                    private boolean officialMember;
                    private boolean softwareAuthor;

                    public boolean isOfficialMember() {
                        return officialMember;
                    }

                    public void setOfficialMember(boolean officialMember) {
                        this.officialMember = officialMember;
                    }

                    public boolean isSoftwareAuthor() {
                        return softwareAuthor;
                    }

                    public void setSoftwareAuthor(boolean softwareAuthor) {
                        this.softwareAuthor = softwareAuthor;
                    }
                }
            }

            public static class StatisticsBean {
                /**
                 * comment : 0
                 * favCount : 0
                 * like : 0
                 * transmit : 0
                 * view : 0
                 */

                private int comment;
                private int favCount;
                private int like;
                private int transmit;
                private int view;

                public int getComment() {
                    return comment;
                }

                public void setComment(int comment) {
                    this.comment = comment;
                }

                public int getFavCount() {
                    return favCount;
                }

                public void setFavCount(int favCount) {
                    this.favCount = favCount;
                }

                public int getLike() {
                    return like;
                }

                public void setLike(int like) {
                    this.like = like;
                }

                public int getTransmit() {
                    return transmit;
                }

                public void setTransmit(int transmit) {
                    this.transmit = transmit;
                }

                public int getView() {
                    return view;
                }

                public void setView(int view) {
                    this.view = view;
                }
            }
        }
    }
}
