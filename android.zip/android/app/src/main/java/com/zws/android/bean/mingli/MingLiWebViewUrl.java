package com.zws.android.bean.mingli;

/**
 * Created by weihao on 2018/3/13.
 */

public class MingLiWebViewUrl {
    /*
    *   八字精批：http://shengtai.polms.cn/index.php/Bzcs/Index/index/t/435/p/1
        八字合婚：http://shengtai.polms.cn/index.php/Bzhh/Index/index/t/435/p/2
        在线起名：http://shengtai.polms.cn/index.php/Zxqm/Index/index/t/435/p/1
        姓名分析：http://shengtai.polms.cn/index.php/Xmfx/Index/index/t/435/p/2

        2018运势：http://shengtai.polms.cn/index.php/Bzcs/Index/index/t/435/p/1
        周公解梦：http://shengtai.polms.cn/index.php/Zgjm1/Index/index/t/435/p/1
        观音灵签:http://shengtai.polms.cn/index.php/Chouqian/Index/index/t/435/p/2
        紫薇斗数：http://shengtai.polms.cn/index.php/Zwpp/Index/index/t/435/p/2


    *
    *
    * */
    public static String[] webViewTitles = new String[]{"八字精批", "八字合婚", "在线起名", "姓名测试", "2018运势", "周公解梦", "观音灵签", "紫薇斗数"};
    public static final String BAZI_PAIPAN = "http://shengtai.polms.cn/index.php/Bzcs/Index/index/t/435/p/1";
    public static final String BAZI_HEHUN = "http://shengtai.polms.cn/index.php/Bzhh/Index/index/t/435/p/2";
    public static final String XINGMING_FENXI = "http://shengtai.polms.cn/index.php/Xmfx/Index/index/t/435/p/2";
    public static final String ZAIXIAN_QIMING = "http://shengtai.polms.cn/index.php/Zxqm/Index/index/t/435/p/1";
    public static final String ZHOUGONG_JIEMENG = "http://shengtai.polms.cn/index.php/Zgjm1/Index/index/t/435/p/1";
    public static final String ZIWEI_PAIPAN = "http://shengtai.polms.cn/index.php/Zwpp/Index/index/t/435/p/2";
    public static final String GUANYIN_LINGQIAN = "http://shengtai.polms.cn/index.php/Chouqian/Index/index/t/435/p/2";
    public static final String YUNSHI = "http://shengtai.polms.cn/index.php/Bzcs/Index/index/t/435/p/1";

}
