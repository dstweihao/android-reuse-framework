package com.zws.android.bean.xuetang;

/**
 * Created by weihao on 2018/3/3.
 */

public class LikeImage {
    private int image;

    public LikeImage(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
